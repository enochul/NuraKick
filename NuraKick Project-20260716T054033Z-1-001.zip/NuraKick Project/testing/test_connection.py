# ====TROUBLESHOOTING:====
# If the sensors are failing to connect immediately, open your computer's bluetooth settings. Click "add device" and then "bluetooth". 
# You don't even need to click on the metawear when it comes up, just scanning the room should cache it and allow connectivity.

from mbientlab.metawear import MetaWear, libmetawear
from mbientlab.metawear.cbindings import *
from time import sleep

# --- USER CONFIGURATION ---
# All sensor MAC addresses in this dictionary. Add third later.
SENSORS = {
    "Leg": "C1:6F:3F:C1:2F:1A",
    "Arm": "C6:0D:15:58:CE:83"
}

# We will store the active connections here
connected_devices = {}

print("--- NuraKick Hardware Test ---")

try:
    # 1. Establish the BLE Connections sequentially
    for name, mac in SENSORS.items():
        print(f"Attempting to connect to {name} ({mac})...")
        device = MetaWear(mac)
        device.connect()
        connected_devices[name] = device
        print(f"Success! Connected to {name}.")

    # 2. Configure the LED pattern (Standard Blink)
    pattern = LedPattern(repeat_count=Const.LED_REPEAT_INDEFINITELY)
    libmetawear.mbl_mw_led_load_preset_pattern(byref(pattern), LedPreset.BLINK)

    # 3. Fire the command to the hardware
    print("\nBlinking LEDs. Leg = RED, Arm = BLUE. Watch the sensors...")
    for name, device in connected_devices.items():
        # Assign colors based on the sensor name"
        if name == "Leg":
            color = LedColor.RED
        elif name == "Arm":
            color = LedColor.BLUE
        libmetawear.mbl_mw_led_write_pattern(device.board, byref(pattern), color)
        libmetawear.mbl_mw_led_play(device.board)

    # Let the test run for 5 seconds
    sleep(5)

    # 4. Cleanup and Disconnect
    print("\nStopping LEDs and safely disconnecting...")
    for name, device in connected_devices.items():
        libmetawear.mbl_mw_led_stop_and_clear(device.board)
        device.disconnect()
        print(f"Disconnected {name}.")

    print("\nTest complete. Session closed.")

except Exception as e:
    print(f"\nError encountered: {e}")
    print("Troubleshooting: Ensure both sensors are awake (green light flashed when unplugged) and close enough to the computer.")
    
    # Safety catch: Disconnect any sensors that DID connect before the crash
    for name, device in connected_devices.items():
        device.disconnect()
        print(f"Emergency disconnect applied to {name}.")