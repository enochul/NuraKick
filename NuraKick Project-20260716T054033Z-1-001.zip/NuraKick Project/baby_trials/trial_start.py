# Four step process of running trials on infants:
# Phase 1: "Fire and Forget"
#   Connect to Arm and Leg, check battery levels, setup sensor, command board
#   to start loggoing data to internally, and safely disconnect
# Phase 2: "Run the Test"
#   Start video recording. Perform the "sync signature" (a short but violent
#   shake). Attach securely to the baby
# Phase 3: "Data Extraction"
#   Recconect to sensors, dowload all the session data over BLE, reconstruct the
#   timestamps, and format the quaternions to write them to a clean .csv
# Phase 4: "Sync Protocol"
#   Manually use the sync signature and timestamps to match real times

from mbientlab.metawear import MetaWear, libmetawear, parse_value
from mbientlab.metawear.cbindings import *
from time import sleep
import threading
import os

SENSORS = {
    "Arm": "C6:0D:15:58:CE:83"
}

print("=== NuraKick Trial Initiation ===")
print("WARNING: This will erase all previous data on the sensors.\n")

connected_devices = {}
callbacks = []

try:
    for name, mac in SENSORS.items():
        print(f"Connecting to {name} ({mac})...")
        device = MetaWear(mac)
        device.connect()
        connected_devices[name] = device
        print(f"  -> {name} Connected.")
    
    pattern = LedPattern(repeat_count=Const.LED_REPEAT_INDEFINITELY)
    libmetawear.mbl_mw_led_load_preset_pattern(byref(pattern), LedPreset.BLINK)
    for name, device in connected_devices.items():
        color = LedColor.RED if name == "Leg" else LedColor.BLUE
        libmetawear.mbl_mw_led_write_pattern(device.board, byref(pattern), color)
        libmetawear.mbl_mw_led_play(device.board)
        
    sleep(3)
    
    for name, device in connected_devices.items():
        libmetawear.mbl_mw_led_stop_and_clear(device.board)

    for name, device in connected_devices.items():
        print(f"\n--- Configuring {name} Sensor ---")

        # 1. Check Battery
        battery_event = threading.Event()
        def battery_handler(context, data):
            bat_state = parse_value(data)
            print(f"  -> Battery: {bat_state.charge}% ({bat_state.voltage}mV)")
            battery_event.set()

        bat_cb = FnVoid_VoidP_DataP(battery_handler)
        callbacks.append(bat_cb)

        bat_signal = libmetawear.mbl_mw_settings_get_battery_state_data_signal(device.board)
        libmetawear.mbl_mw_datasignal_subscribe(bat_signal, None, bat_cb)
        libmetawear.mbl_mw_datasignal_read(bat_signal)
        battery_event.wait(timeout=2.0)

        # 2. Setup Sensor Fusion (FIXED: IMU_PLUS ignores the compass)
        libmetawear.mbl_mw_sensor_fusion_set_mode(device.board, SensorFusionMode.IMU_PLUS)
        libmetawear.mbl_mw_sensor_fusion_set_acc_range(device.board, SensorFusionAccRange._8G)
        libmetawear.mbl_mw_sensor_fusion_set_gyro_range(device.board, SensorFusionGyroRange._2000DPS)
        libmetawear.mbl_mw_sensor_fusion_write_config(device.board)
        sleep(0.1)

        signal = libmetawear.mbl_mw_sensor_fusion_get_data_signal(device.board, SensorFusionData.QUATERNION)

        # 3. Route Data to Flash Memory
        logger_event = threading.Event()
        logger_success = {"status": False} 
        
        def logger_handler(context, logger):
            if logger:
                print(f"  -> Flash memory allocated successfully.")
                logger_success["status"] = True
            else:
                logger_success["status"] = False
            logger_event.set()
            
        log_cb = FnVoid_VoidP_VoidP(logger_handler)
        callbacks.append(log_cb)
        
        libmetawear.mbl_mw_datasignal_log(signal, None, log_cb)
        logger_event.wait(timeout=5.0)

        if not logger_success["status"]:
            raise RuntimeError(f"Board routing table is full. Run nuke_boards.py.")

        # 4. START SENSORS FIRST (Feeds the algorithm)
        libmetawear.mbl_mw_acc_enable_acceleration_sampling(device.board)
        libmetawear.mbl_mw_acc_start(device.board)
        libmetawear.mbl_mw_gyro_bmi160_enable_rotation_sampling(device.board)
        libmetawear.mbl_mw_gyro_bmi160_start(device.board)

        # 5. START ALGORITHM & LOGGING
        libmetawear.mbl_mw_sensor_fusion_enable_data(device.board, SensorFusionData.QUATERNION)
        libmetawear.mbl_mw_sensor_fusion_start(device.board)
        libmetawear.mbl_mw_logging_start(device.board, 1)

        print(f"  -> {name} is now actively logging autonomously.")

    print("\n=== TRIAL STARTED SUCCESSFULLY ===")
    print("Sensors are now logging. You may now perform the 3-tap sync and begin the infant trial.")

    print("\n--- Saving Digital State (Serialization) ---")
    for name, device in connected_devices.items():
        size = c_uint(0)
        state_ptr = libmetawear.mbl_mw_metawearboard_serialize(device.board, byref(size))
        
        with open(f"{name}_state.bin", "wb") as f:
            f.write(string_at(state_ptr, size.value))
            
        libmetawear.mbl_mw_memory_free(state_ptr)
        print(f"  -> {name} state saved to {name}_state.bin")

except Exception as e:
    print(f"\nCRITICAL ABORT: {e}")

finally:
    print("\nSafely dropping Bluetooth connection...")
    for name, device in connected_devices.items():
        try:
            device.disconnect()
            print(f"  -> Severed connection to {name}.")
        except Exception:
            pass
            
    sleep(1.0)
    os._exit(0) # Hard exit to prevent the C++ segfault